package com.sabropedia.models;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "local")
public class Local {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(unique = true)
	@NotBlank(message = "Por favor proporciona el nombre de tu local")
	@Size(min = 5, message = "El titulo debe tener como minimo 5 caracteres" )
	private String nombreLocal;
	
	@NotBlank(message = "Por favor proporciona la descripcion de su local")
	@Size(min = 10, message = "La descripcion debe tener como minimo 10 caracteres" )
	private String descripcion;
	
	@OneToMany(mappedBy = "local", cascade = CascadeType.ALL)
    private List<Categoria> categorias;
	
	private String imagenLocal;
	
	@Transient
	private MultipartFile imagen;
	
	@ManyToOne
	@JoinColumn(name= "id_usuario")
	private UsuarioLocal creador;
	
	@OneToMany(mappedBy = "local", cascade = CascadeType.ALL)
	private List<Plato> platos;
	
	@OneToMany(mappedBy = "local", cascade = CascadeType.ALL)
	private List<Comentario> comentarios;

	public Local(Long id, String nombreLocal, String descripcion, List<Categoria> categoria, String imagenLocal,UsuarioLocal creador, List<Plato> platos, List<Comentario> comentarios) {
		super();
		this.id = id;
		this.nombreLocal = nombreLocal;
		this.descripcion = descripcion;
		this.categorias = categoria;
		this.imagenLocal = imagenLocal;
		this.creador = creador;
		this.platos = platos;
		this.comentarios = comentarios;
	}
	
	public Local() {
		this.id = 0l;
		this.nombreLocal = "";
		this.descripcion = "";
		this.categorias= null;
		this.imagenLocal = "";
		this.creador = null;
		this.platos = null;
		this.comentarios = null;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombreLocal() {
		return nombreLocal;
	}

	public void setNombreLocal(String nombreLocal) {
		this.nombreLocal = nombreLocal;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public List<Categoria> getCategoria() {
		return categorias;
	}

	public void setCategoria(List<Categoria> categorias) {
		this.categorias = categorias;
	}

	public UsuarioLocal getCreador() {
		return creador;
	}

	public void setCreador(UsuarioLocal creador) {
		this.creador = creador;
	}

	public List<Plato> getPlatos() {
		return platos;
	}

	public void setPlatos(List<Plato> platos) {
		this.platos = platos;
	}

	public List<Comentario> getComentarios() {
		return comentarios;
	}

	public void setComentarios(List<Comentario> comentarios) {
		this.comentarios = comentarios;
	}

	public String getImagenLocal() {
		return imagenLocal;
	}

	public void setImagenLocal(String imagenLocal) {
		this.imagenLocal = imagenLocal;
	}

	public MultipartFile getImagen() {
		return imagen;
	}

	public void setImagen(MultipartFile imagen) {
		this.imagen = imagen;
	}

}