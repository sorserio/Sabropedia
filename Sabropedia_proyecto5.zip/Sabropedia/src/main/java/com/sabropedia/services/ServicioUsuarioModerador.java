package com.sabropedia.services;

import java.util.List;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import com.sabropedia.models.LoginUsuarioModerador;
import com.sabropedia.models.UsuarioModerador;
import com.sabropedia.repositories.RepositorioUsuarioModerador;

@Service
public class ServicioUsuarioModerador {
	
	@Autowired
	RepositorioUsuarioModerador repositorioUsuarioModerador;
	
	public UsuarioModerador crear(UsuarioModerador usuarioModerador) { 
		String hashPassword = BCrypt.hashpw(usuarioModerador.getContraseña(), BCrypt.gensalt());
		usuarioModerador.setContraseña(hashPassword);
		return this.repositorioUsuarioModerador.save(usuarioModerador);
	}

	public List<UsuarioModerador> obtenerTodosLosUsuariosLocal() {
		return (List<UsuarioModerador>) this.repositorioUsuarioModerador.findAll();
	}

	public UsuarioModerador obtenerPorId(Long id) {
		return this.repositorioUsuarioModerador.findById(id).orElse(null);
	}

	public UsuarioModerador obtenerPorEmail(String email) {
		return this.repositorioUsuarioModerador.findByEmail(email).orElse(null);
	}

	public UsuarioModerador actualizar(UsuarioModerador usuarioModerador) {
		return this.repositorioUsuarioModerador.save(usuarioModerador);
	}

	public void eliminarPorId(Long id) {
		this.repositorioUsuarioModerador.deleteById(id);
	}

	
	public BindingResult validarRegistro(BindingResult validaciones, UsuarioModerador usuarioModerador) {
		if (!usuarioModerador.getContraseña().equals(usuarioModerador.getConfirmarContraseña())) {
			validaciones.rejectValue("confirmarContraseña", "contraseñaNoCoincide", "La contraseñas no coinciden.");
		}
		return validaciones;
	}

	public BindingResult validarLogin(BindingResult validaciones, LoginUsuarioModerador usuarioModerador) {
		UsuarioModerador usuarioModeradorDb = this.obtenerPorEmail(usuarioModerador.getCorreo());
		if (usuarioModeradorDb == null) {
			validaciones.rejectValue("correo", "correoNoRegistrado",
					"El correo electrónico ingresado no se encuentra en nuestra base de datos.");
		} else {
			if (!BCrypt.checkpw(usuarioModerador.getContraseña(), usuarioModeradorDb.getContraseña())) {
				validaciones.rejectValue("contraseña", "contraseñaIncorrecta", "Contraseña incorrecta.");
			}
		}
		return validaciones;
	}

}
