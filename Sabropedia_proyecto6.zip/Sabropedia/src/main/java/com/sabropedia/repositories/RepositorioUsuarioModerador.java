package com.sabropedia.repositories;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sabropedia.models.UsuarioModerador;

@Repository
public interface RepositorioUsuarioModerador extends CrudRepository<UsuarioModerador, Long>{
	
	Optional<UsuarioModerador> findByEmail(String email);
}
