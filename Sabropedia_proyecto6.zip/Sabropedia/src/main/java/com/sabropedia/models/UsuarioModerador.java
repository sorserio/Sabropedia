package com.sabropedia.models;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(name="moderadores")
public class UsuarioModerador {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotBlank(message = "Por favor proporciona tu nombre")
	@Size(min = 3, message = "El nombre debe contener al menos 3 caracteres")
	private String nombre;
	
	@NotBlank(message = "Por favor proporciona tu apellido") 
	@Size(min = 3, message = "El apellido debe contener al menos 3 caracteres.")
	private String apellido;
	
	@Column(unique = true)
	@NotBlank(message = "El campo es requerido")
	@Email(message = "Por favor ingresa un correo valido")
	private String email;
	
	@NotBlank(message = "El campo es requerido")
	@Size(min= 8, message = "Debe contener al menos 8 caracteres")
	private String contraseña;
	
	@Transient
	private String confirmarContraseña;
	

	@ManyToMany
	@JoinTable(name = "locales_moderadores", joinColumns = @JoinColumn(name= "id_moderador"), inverseJoinColumns = @JoinColumn(name = "id_local"))
	@Transient	private List<Local> localesModerados;
	
	@ManyToMany
	@JoinTable(name = "platos_moderadores", joinColumns = @JoinColumn(name= "id_moderador"), inverseJoinColumns = @JoinColumn(name = "id_plato"))
	@Transient
	private List<Plato> platosModerados;
	
	@ManyToMany
	@JoinTable(name = "comentarios_moderadores", joinColumns = @JoinColumn(name= "id_moderador"), inverseJoinColumns = @JoinColumn(name = "id_comentario"))
	@Transient
	private List<Comentario> comentariosModerados;

	public UsuarioModerador(Long id, String nombre, String apellido, String email, String contraseña,
			String confirmarContraseña,  List<Local> localesModerados, List<Plato> platosModerados,
			List<Comentario> comentariosModerados) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.email = email;
		this.contraseña = contraseña;
		this.confirmarContraseña = confirmarContraseña;
		this.localesModerados = localesModerados;
		this.platosModerados = platosModerados;
		this.comentariosModerados = comentariosModerados;
	}
	
	public UsuarioModerador() {
		super();
		this.id = 0l;
		this.nombre = "";
		this.apellido = "";
		this.email = "";
		this.contraseña = "";
		this.confirmarContraseña = "";
		this.localesModerados = null;
		this.platosModerados = null;
		this.comentariosModerados = null;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContraseña() {
		return contraseña;
	}

	public void setContraseña(String contraseña) {
		this.contraseña = contraseña;
	}

	public String getConfirmarContraseña() {
		return confirmarContraseña;
	}

	public void setConfirmarContraseña(String confirmarContraseña) {
		this.confirmarContraseña = confirmarContraseña;
	}

	public  List<Local> getLocalesModerados() {
		return localesModerados;
	}

	public void setLocalesModerados( List<Local> localesModerados) {
		this.localesModerados = localesModerados;
	}

	public List<Plato> getPlatosModerados() {
		return platosModerados;
	}

	public void setPlatosModerados(List<Plato> platosModerados) {
		this.platosModerados = platosModerados;
	}

	public List<Comentario> getComentariosModerados() {
		return comentariosModerados;
	}

	public void setComentariosModerados(List<Comentario> comentariosModerados) {
		this.comentariosModerados = comentariosModerados;
	}
	
}
	
	
	
	

