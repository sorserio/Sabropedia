package com.sabropedia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sabropedia1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
