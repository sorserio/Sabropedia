package com.sabropedia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sabropedia1Application {

	public static void main(String[] args) {
		SpringApplication.run(Sabropedia1Application.class, args);
	}

}
