package com.sabropedia.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.sabropedia.models.Comentario;
import com.sabropedia.models.Comercio;
import com.sabropedia.models.UsuarioComercio;
import com.sabropedia.services.ServicioCategorias;
import com.sabropedia.services.ServicioComentarios;
import com.sabropedia.services.ServicioComercios;
import com.sabropedia.services.ServicioUsuariosComercio;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class ControladorComercios {
	
	@Autowired
	private ServicioComercios servicioComercios;
	
	@Autowired 
	private ServicioUsuariosComercio servicioUsuariosComercio;
	
	@Autowired
	private ServicioCategorias servicioCategorias;
	
	@Autowired
	private ServicioComentarios servicioComentarios;
	
	@GetMapping("/inicio")
	private String prueba(HttpSession sesion, Model modelo, UsuarioComercio usuarioComercio) {
		Long idGerencial = (Long) sesion.getAttribute("idGerencial");
		modelo.addAttribute("comercios", this.servicioComercios.obtenerTodosLosComercios());
		modelo.addAttribute("idGerente", this.servicioUsuariosComercio.obtenerPorId(idGerencial).getComercio());
		return "index.jsp";
	}
	
	@GetMapping("/cafeterias")
	private String cafeterias(HttpSession sesion, Model modelo, UsuarioComercio usuarioComercio) {
		Long idGerencial = (Long) sesion.getAttribute("idGerencial");
		modelo.addAttribute("comercios", this.servicioComercios.obtenerTodosLosComercios());
		modelo.addAttribute("categorias",this.servicioCategorias.obtenerTodasLasCategorias());
		modelo.addAttribute("idGerente", this.servicioUsuariosComercio.obtenerPorId(idGerencial).getComercio());
		return "cafeterias.jsp";
	}
	
	@GetMapping("/foodtrucks")
	private String foodTrucks(HttpSession sesion, Model modelo, UsuarioComercio usuarioComercio) {
		Long idGerencial = (Long) sesion.getAttribute("idGerencial");
		modelo.addAttribute("comercios", this.servicioComercios.obtenerTodosLosComercios());
		modelo.addAttribute("categorias",this.servicioCategorias.obtenerTodasLasCategorias());
		modelo.addAttribute("idGerente", this.servicioUsuariosComercio.obtenerPorId(idGerencial).getComercio());
		return "foodtrucks.jsp";
	}
	
	@GetMapping("/heladerias")
	private String heladerias(HttpSession sesion, Model modelo, UsuarioComercio usuarioComercio) {
		Long idGerencial = (Long) sesion.getAttribute("idGerencial");
		modelo.addAttribute("comercios", this.servicioComercios.obtenerTodosLosComercios());
		modelo.addAttribute("categorias",this.servicioCategorias.obtenerTodasLasCategorias());
		modelo.addAttribute("idGerente", this.servicioUsuariosComercio.obtenerPorId(idGerencial).getComercio());
		return "heladerias.jsp";
	}
	
	@GetMapping("/restaurantes")
	private String restaurantes(HttpSession sesion, Model modelo, UsuarioComercio usuarioComercio) {
		Long idGerencial = (Long) sesion.getAttribute("idGerencial");
		modelo.addAttribute("comercios", this.servicioComercios.obtenerTodosLosComercios());
		modelo.addAttribute("categorias",this.servicioCategorias.obtenerTodasLasCategorias());
		modelo.addAttribute("idGerente", this.servicioUsuariosComercio.obtenerPorId(idGerencial).getComercio());
		return "restaurantes.jsp";
	}
	
	
	
	@GetMapping("/form/agregar")
	public String agregar(HttpSession sesion, Model modelo) {
		if (sesion.getAttribute("idGerencial") == null) {
			return "redirect:/";
		}
		modelo.addAttribute("comercio", new Comercio());
		modelo.addAttribute("categorias", servicioCategorias.obtenerTodasLasCategorias());
		return "agregar.jsp";
	}
	
	@GetMapping("/form/editar/{id}")
	public String editar(@PathVariable("id") Long id, HttpSession sesion, Model modelo, @ModelAttribute("comercio") Comercio comercio) {
		if (sesion.getAttribute("idGerencial") == null) {
			return "redirect:/";
		}
		modelo.addAttribute("comercio", this.servicioComercios.obtenerPorId(id));
		return "editar.jsp";
	}
	
	@PostMapping("/guardar")
	public String guardar(
	        HttpSession sesion,
	        @Valid @ModelAttribute("comercio") Comercio comercio,
	        BindingResult validaciones,
	        Model modelo,
	        @RequestParam("imagenComercioTransient") MultipartFile imagenComercioTransient,
	        @RequestParam("imagenLogoTransient") MultipartFile imagenLogoTransient,
	        @RequestParam("imagenGaleriaTransient") List<MultipartFile> imagenGaleriaTransient) {

	    // Verificar sesión
	    if (sesion.getAttribute("idGerencial") == null) {
	        return "redirect:/";
	    }

	    // Validaciones estándar del modelo
	    if (validaciones.hasErrors()) {
	        modelo.addAttribute("categorias", servicioCategorias.obtenerTodasLasCategorias());
	        return "agregar.jsp";
	    }

	    // Validación de imágenes
	    if (imagenComercioTransient.isEmpty()) {
	        modelo.addAttribute("errorImagenComercio", "Debe subir una imagen para el comercio.");
	        return "agregar.jsp";
	    }

	    if (imagenLogoTransient.isEmpty()) {
	        modelo.addAttribute("errorImagenLogo", "Debe subir un logo.");
	        return "agregar.jsp";
	    }

	    if (imagenGaleriaTransient == null || imagenGaleriaTransient.isEmpty()) {
	        modelo.addAttribute("errorImagenGaleria", "Debe subir al menos una imagen para la galería.");
	        return "agregar.jsp";
	    }

	    try {
	        // Procesar imágenes y guardar rutas en el modelo
	        if (!imagenComercioTransient.isEmpty()) {
	            String nombreImg = ControladorImagenes.uploadImg(imagenComercioTransient);
	            comercio.setImagenComercio(nombreImg);
	        }

	        if (!imagenLogoTransient.isEmpty()) {
	            String nombreImg = ControladorImagenes.uploadImg(imagenLogoTransient);
	            comercio.setImagenLogo(nombreImg);
	        }

	        if (!imagenGaleriaTransient.isEmpty()) {
	            List<String> rutasGaleria = ControladorImagenes.uploadImgs(imagenGaleriaTransient);
	            comercio.setImagenesGaleria(rutasGaleria);
	        }

	        // Guardar comercio
	        this.servicioComercios.crear(comercio);
	    } catch (Exception e) {
	        e.printStackTrace();
	        modelo.addAttribute("error", "Error al procesar las imágenes. Inténtelo nuevamente.");
	        modelo.addAttribute("categorias", servicioCategorias.obtenerTodasLasCategorias());
	        return "agregar.jsp";
	    }

	    return "redirect:/inicio";
	}
	
	@PutMapping("/actualizar/{id}")
	public String actualizar(@PathVariable("id") Long id, HttpSession sesion, @Valid @ModelAttribute("local") Comercio comercio, BindingResult validaciones ) {
		if (sesion.getAttribute("idGerencial") == null) {
			return "redirect:/";
		}
		if(validaciones.hasErrors()) {
			return "editar.jsp";
		}
		this.servicioComercios.actualizar(comercio);
		return "redirect:/inicio";
		
		
	}
	
	@DeleteMapping("/eliminar/{id}")
	public String eliminar(@PathVariable("id") Long id, HttpSession sesion) {
		if (sesion.getAttribute("idGerencial") == null) {
			return "redirect:/";
		}
		this.servicioComercios.eliminarPorId(id);
		return "redirect:/";
		
	}
	
	@GetMapping("/detalle/{id}")
	public String detalle(@PathVariable("id") Long id, HttpSession sesion, Model modelo) {
		if (sesion.getAttribute("idGerencial") == null) {
			return "redirect:/";
		}
		modelo.addAttribute("local", this.servicioComercios.obtenerPorId(id));
		return "detalle.jsp";
		
	}
	
	@GetMapping("/form/comentar/{id}")
	public String comentar(@PathVariable("id") Long id, HttpSession sesion, Model modelo) {
		if (sesion.getAttribute("nombreCompleto") == null) {
			return "redirect:/";
		}
		modelo.addAttribute("local", this.servicioComercios.obtenerPorId(id));
		modelo.addAttribute("comentario", new Comentario());
		return "comentar.jsp";
	}	
		
	@PostMapping("/comentar")
	public String comentar(HttpSession sesion, @Valid @ModelAttribute("comentario") Comentario comentario, BindingResult validaciones) {
		if (sesion.getAttribute("nombreCompleto") == null) {
			return "redirect:/";
		}
		if(validaciones.hasErrors()) {
			return "comentar.jsp";
		}
		servicioComentarios.crear(comentario);
		return "redirect:/inicio";
	}

}
